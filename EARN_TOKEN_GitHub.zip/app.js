(() => {
  "use strict";


  const USERS_KEY = "earn_token_users_v3";
  const SESSION_KEY = "earn_token_session_v3";
  const WHEEL_DELAY = 24 * 60 * 60 * 1000;
  const REWARDS = [100, 200, 300, 400, 500];


  let currentUser = null;


  const $ = id => document.getElementById(id);


  function getUsers() {
    try {
      const data = JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
      return Array.isArray(data) ? data : [];
    } catch (error) {
      return [];
    }
  }


  function saveUsers(users) {
    try {
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      return true;
    } catch (error) {
      alert("Erreur de sauvegarde.");
      return false;
    }
  }


  function saveCurrentUser() {
    if (!currentUser) return false;
    const users = getUsers();
    const index = users.findIndex(u => u.id === currentUser.id);
    if (index < 0) return false;
    users[index] = currentUser;
    return saveUsers(users);
  }


  function register(event) {
    event.preventDefault();


    const nom = $("regNom").value.trim();
    const prenom = $("regPrenom").value.trim();
    const phone = $("regPhone").value.trim();
    const password = $("regPassword").value;
    const confirm = $("regConfirm").value;


    if (!nom || !prenom || !phone || !password || !confirm) {
      alert("Remplis tous les champs.");
      return;
    }


    if (password.length < 8) {
      alert("Le mot de passe doit contenir au moins 8 caractères.");
      return;
    }


    if (password !== confirm) {
      alert("Les mots de passe ne correspondent pas.");
      return;
    }


    const users = getUsers();


    if (users.some(user => user.phone === phone)) {
      alert("Ce numéro est déjà inscrit. Connecte-toi.");
      return;
    }


    const user = {
      id: "ET-" + Date.now(),
      nom,
      prenom,
      phone,
      password,
      balance: 500,
      fictionalBalance: 0,
      dailyIncome: 0,
      earnings: 0,
      levels: [],
      history: [{
        label: "Bonus de bienvenue",
        reward: 500,
        date: new Date().toISOString()
      }],
      wheelLastAt: null,
      isCreator: users.length === 0
    };


    users.push(user);
    if (!saveUsers(users)) return;


    currentUser = user;
    localStorage.setItem(SESSION_KEY, user.id);
    $("registerForm").reset();
    startApp();
  }


  function login(event) {
    event.preventDefault();


    const phone = $("loginPhone").value.trim();
    const password = $("loginPassword").value;


    const user = getUsers().find(item => item.phone === phone && item.password === password);


    if (!user) {
      alert("Numéro ou mot de passe incorrect.");
      return;
    }


    currentUser = user;
    localStorage.setItem(SESSION_KEY, user.id);
    $("loginForm").reset();
    startApp();
  }


  function startApp() {
    $("authSection").classList.add("hidden");
    $("appSection").classList.remove("hidden");
    $("bottomNav").classList.remove("hidden");
    $("headerUser").textContent = "Bonjour " + currentUser.prenom;


    renderUser();
    updateWheel();
    showPage("home");
  }


  function renderUser() {
    const totalBalance = currentUser.balance + (currentUser.fictionalBalance || 0);
    $("balance").textContent = totalBalance.toLocaleString();
    $("dailyIncome").textContent = currentUser.dailyIncome.toLocaleString();
    $("earnings").textContent = currentUser.earnings.toLocaleString();
    
    $("profileName").textContent = currentUser.prenom + " " + currentUser.nom;
    $("profilePhone").textContent = currentUser.phone;
    $("profileId").textContent = currentUser.id;


    if (currentUser.fictionalBalance > 0) {
      $("fictionalNotice").classList.remove("hidden");
      $("fictionalAmt").textContent = currentUser.fictionalBalance.toLocaleString();
    } else {
      $("fictionalNotice").classList.add("hidden");
    }


    const link = "https://earntoken.app/ref?id=" + encodeURIComponent(currentUser.id);
    $("refLink").textContent = link;


    const list = $("historyList");
    list.replaceChildren();


    [...currentUser.history].reverse().forEach(item => {
      const row = document.createElement("div");
      row.className = "history-item";


      const label = document.createElement("span");
      label.textContent = item.label;


      const amount = document.createElement("strong");
      amount.className = item.reward >= 0 ? "green" : "";
      amount.style.color = item.reward < 0 ? "#ff4d4d" : "";
      amount.textContent = (item.reward >= 0 ? "+" : "") + item.reward + " FCFA";


      row.append(label, amount);
      list.appendChild(row);
    });


    document.querySelectorAll(".buyBtn").forEach(button => {
      const lvl = Number(button.dataset.lvl);
      const unlocked = (currentUser.levels || []).includes(lvl);
      button.disabled = unlocked;
      button.textContent = unlocked ? "Débloqué ✅" : "Débloquer (" + Number(button.dataset.cost).toLocaleString() + " FCFA)";
    });
  }


  function showPage(page) {
    document.querySelectorAll(".page").forEach(section => {
      section.classList.add("hidden");
    });


    const target = $("page-" + page);
    if (target) {
      target.classList.remove("hidden");
    }


    document.querySelectorAll(".nav button").forEach(button => {
      button.classList.toggle("active", button.dataset.page === page);
    });


    if (page === "wheel") updateWheel();
  }


  function buyLevel(lvl, cost, income) {
    if ((currentUser.levels || []).includes(lvl)) return;
    
    if (currentUser.balance < cost) {
      alert("Solde insuffisant pour débloquer ce niveau.");
      return;
    }


    if (!confirm("Confirmer le déblocage du niveau " + lvl + " pour " + cost.toLocaleString() + " FCFA ?")) return;


    currentUser.balance -= cost;
    currentUser.dailyIncome += income;
    if (!currentUser.levels) currentUser.levels = [];
    currentUser.levels.push(lvl);


    currentUser.history.push({
      label: "Déblocage Niveau " + lvl,
      reward: -cost,
      date: new Date().toISOString()
    });


    if (saveCurrentUser()) {
      renderUser();
      alert("Niveau " + lvl + " débloqué avec succès !");
    }
  }


  function playWheel() {
    if (!currentUser) return;


    const now = Date.now();
    const last = Number(currentUser.wheelLastAt || 0);


    if (last && now - last < WHEEL_DELAY) {
      alert("Tu as déjà participé aujourd'hui. Reviens après 24 heures.");
      updateWheel();
      return;
    }


    const reward = REWARDS[Math.floor(Math.random() * REWARDS.length)];


    currentUser.wheelLastAt = now;
    currentUser.balance += reward;
    currentUser.history.push({
      label: "Gains Roue de la fortune",
      reward,
      date: new Date().toISOString()
    });


    if (saveCurrentUser()) {
      renderUser();
      $("wheelResult").textContent = "Bravo ! Tu gagnes " + reward + " FCFA !";
      updateWheel();
    }
  }


  function updateWheel() {
    if (!currentUser) return;


    const last = Number(currentUser.wheelLastAt || 0);
    const remaining = WHEEL_DELAY - (Date.now() - last);


    if (last && remaining > 0) {
      $("spinBtn").disabled = true;
      const hours = Math.floor(remaining / 3600000);
      const minutes = Math.floor((remaining % 3600000) / 60000);
      $("spinBtn").textContent = "DISPONIBLE DANS " + hours + "H " + minutes + "M";
      $("wheelTimer").textContent = "Prochaine participation dans 24 heures.";
    } else {
      $("spinBtn").disabled = false;
      $("spinBtn").textContent = "LANCER LA ROUE";
      $("wheelTimer").textContent = "Ta participation est disponible !";
    }
  }


  function openAdmin() {
    if (!currentUser || currentUser.isCreator !== true) {
      alert("Accès réservé au compte créateur de cette démonstration.");
      return;
    }
    const balance = prompt("Solde principal fictif (FCFA) :", currentUser.balance || 0);
    if (balance === null) return;
    const fictional = prompt("Avoirs fictifs supplémentaires (FCFA) :", currentUser.fictionalBalance || 0);
    if (fictional === null) return;
    const earnings = prompt("Gains cumulés fictifs (FCFA) :", currentUser.earnings || 0);
    if (earnings === null) return;
    const daily = prompt("Revenu journalier affiché (FCFA) :", currentUser.dailyIncome || 0);
    if (daily === null) return;
    const values = [balance, fictional, earnings, daily].map(v => Number(v));
    if (values.some(v => !Number.isSafeInteger(v) || v < 0)) {
      alert("Entre uniquement des nombres entiers positifs ou égaux à zéro.");
      return;
    }
    const [oldBalance, oldFictional, oldEarnings, oldDaily] = [currentUser.balance || 0, currentUser.fictionalBalance || 0, currentUser.earnings || 0, currentUser.dailyIncome || 0];
    [currentUser.balance, currentUser.fictionalBalance, currentUser.earnings, currentUser.dailyIncome] = values;
    currentUser.history = currentUser.history || [];
    currentUser.history.push({ label: "Modification des avoirs fictifs du créateur", reward: (values[0]+values[1])-(oldBalance+oldFictional), date: new Date().toISOString() });
    if (saveCurrentUser()) {
      renderUser();
      alert("Avoirs de démonstration mis à jour. Aucun argent réel n'a été ajouté.");
    }
  }


  function copyLink() {
    const link = $("refLink").textContent;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(link).then(() => alert("Lien copié !"));
    } else {
      alert("Sélectionne et copie le lien.");
    }
  }


  function logout() {
    if (!confirm("Veux-tu te déconnecter ?")) return;
    localStorage.removeItem(SESSION_KEY);
    currentUser = null;


    $("appSection").classList.add("hidden");
    $("bottomNav").classList.add("hidden");
    $("authSection").classList.remove("hidden");
    $("headerUser").textContent = "Bienvenue";
    $("loginBox").classList.remove("hidden");
    $("registerBox").classList.add("hidden");
  }

  function restoreSession() {
    const id = localStorage.getItem(SESSION_KEY);
    if (!id) return;
    const user = getUsers().find(item => item.id === id);
    if (user) { currentUser = user; startApp(); }
    else localStorage.removeItem(SESSION_KEY);
  }

  $("registerForm").addEventListener("submit", register);
  $("loginForm").addEventListener("submit", login);
  $("goLogin").addEventListener("click", () => {
    $("registerBox").classList.add("hidden");
    $("loginBox").classList.remove("hidden");
  });
  $("goRegister").addEventListener("click", () => {
    $("loginBox").classList.add("hidden");
    $("registerBox").classList.remove("hidden");
  });
  document.querySelectorAll(".nav button").forEach(button => button.addEventListener("click", () => showPage(button.dataset.page)));
  document.querySelectorAll(".buyBtn").forEach(button => button.addEventListener("click", () => buyLevel(Number(button.dataset.lvl), Number(button.dataset.cost), Number(button.dataset.income))));
  $("spinBtn").addEventListener("click", playWheel);
  $("copyLink").addEventListener("click", copyLink);
  $("logoutBtn").addEventListener("click", logout);
  $("adminTriggerBtn").addEventListener("click", openAdmin);
  $("dailyClaimBtn").addEventListener("click", () => alert("Le pointage journalier est une simulation. Aucun revenu réel n'est généré."));
  $("depositBtn").addEventListener("click", () => alert("Dépôt désactivé : cette démonstration ne reçoit aucun paiement réel."));
  $("withdrawBtn").addEventListener("click", () => alert("Retrait impossible : tous les crédits sont fictifs et non convertibles en argent."));

  restoreSession();
})();
